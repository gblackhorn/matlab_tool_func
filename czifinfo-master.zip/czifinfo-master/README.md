# czifinfo

CZIFINFO returns informaion of Zeiss CZI file

czifinfo returns information of czi file includingl pixel type,
compression method, fileGUID, file version number, a structure
recording various information of raw image data including data start
position within the czi file, data size and spatial coordinates. Also
the function returns associated metadata in the field named 'XML_text'.
This can be saved as an .xml file and examined in web browser. 

Version 1.0
Copyright Chao-Yuan Yeh, 2016
